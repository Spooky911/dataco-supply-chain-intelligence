# DataCo supply chain: management brief

**Coverage:** 1 January 2015–31 January 2018. The analysis covers all 180,519 order items and 65,752 distinct orders in the supplied CSV. This is a historical snapshot, not a view of current operations. Monetary amounts use the source's units because its currency is undocumented.

## Executive assessment

The dataset records 33.05 million in sales after discounts and 3.97 million in benefit, producing a recorded margin of 12.0%. That positive headline sits alongside two issues worth management attention: frequent missed delivery commitments and a pronounced decline in basket value at the end of the reporting period. Neither should be attributed to a single operational cause without checking the source and supporting business records.

## Delivery promises are the clearest service concern

Of 62,897 orders with noncanceled shipments, 36,048 were classified as late: a 57.3% late-delivery rate. First Class is especially striking: all 9,602 eligible orders were late against the one-day scheduled window. Second Class was late on 80.0% of eligible orders, compared with 39.8% for Standard Class and 48.4% for Same Day.

This does not mean that Standard Class physically moves faster. First Class averaged two actual days against a one-day promise; Standard Class averaged approximately four actual days against a four-day promise. The difference concerns reliability against the commitment made to the customer. Review the promise-setting logic, order processing times and service definitions before deciding to redirect orders between modes. The unusually consistent patterns also warrant a check of whether the source represents observed operations or a constructed training dataset.

**Recommended decision:** begin a service review with First Class and Second Class. Request carrier milestones and verified delivery-completion timestamps to distinguish processing delays from transit delays. Avoid estimating carrier performance or freight savings from this file; neither carrier nor freight cost is available.

## Order growth masks a fall in basket value

January 2018 recorded 2,123 orders, up 21.7% from January 2017, while net booked sales fell from 0.93 million to 0.30 million, a decline of 67.8%. Average order value consequently fell from approximately 530.36 to 140.35. The divergence is visible from late 2017 and deserves investigation before it is described as weakening customer demand.

**Recommended decision:** reconcile the late-period extract with the source owner, then compare products, quantities, item counts and market mix against the earlier period. Compare January with January; a single month of 2018 should not be compared with a full year of 2017. The report's date filters support comparable periods.

## Aggregate profit conceals a meaningful loss burden

At the whole-order level, 13,909 orders had a negative sum of recorded item benefit, representing 21.2% of orders. Together these orders contributed approximately −2.62 million. This is distinct from the 33,784 individual items with negative benefit: an order can contain a loss-making item and still be profitable overall.

**Recommended decision:** review the largest negative-benefit orders and their product and discount composition. Treat discount and delivery comparisons as diagnostic associations. The file does not establish whether losses arose from promotions, returns, product cost, freight or data-generation rules. Profitability under a product or category filter describes the selected items in each order, not necessarily the full basket.

## Focus commercial reviews where the value is concentrated

Europe generated 9.77 million in net booked sales and LATAM generated 9.24 million. Together they account for approximately 57.5% of total value. Fishing was the largest product category, with 6.23 million in net booked sales and 0.76 million in recorded profit.

**Recommended decision:** start margin and destination-route reviews with these high-value segments, while checking delivery rates alongside eligible order counts. Avoid treating extreme rates in low-volume cities as equivalent to a sustained issue on a major route.

## Definitions and evidence limits

- **Grain:** one row per order item. Order Item ID is unique across all rows. Shipping mode, delivery status, shipping-day fields, date, order status and destination country are consistent within each order in this extract.
- **Gross sales:** sum of Sales. **Net booked sales:** sum of Order Item Total. **Recorded profit:** sum of Benefit per order. Despite their names, Benefit per order and Order Profit Per Order are identical at item level; Sales per customer and Order Item Total are also identical. The report uses one field from each pair.
- **Recorded margin:** total recorded benefit divided by total net booked sales. This is a weighted ratio, not the average item profit ratio. It includes only costs embedded in the supplied benefit field.
- **Delivery eligibility:** exclude Shipping canceled; count distinct orders. Early and on-time shipments both meet their scheduled window. Canceled shipments are 2,855 orders, or 4.3% of all orders, and include canceled and suspected-fraud order statuses.
- **Order-weighted days:** average each order's actual or scheduled days once. Averaging every item would overweight larger baskets.
- **Geography:** order city, state, country and region are destinations. Customer city and country describe the customer location. The dictionary assigns latitude and longitude to the store location; they must not be used to map delivery destinations.
- **Dates:** there is an order timestamp and a field labeled shipping timestamp, but no independently verified arrival date. Shipping timestamp minus order timestamp differs from actual shipping days in 9,737 items (5.4%). No arrival date is fabricated in the report.
- **Statuses:** pending and processing orders also carry delivery labels, so this is not a validated live delivery-tracking model. Financial totals include all statuses. Closed/complete amounts are a status subtotal, not recognized revenue or settled cash.
- **Missingness:** Product Description is entirely blank; Order Zipcode is missing in about 86.2% of rows. Neither supports meaningful segmentation. Personal names, street addresses and customer coordinates are omitted from the report model.
- **Rounding:** gross sales minus net booked sales differs slightly from summed discount values because of source numeric precision. Reconcile rounded totals with a tolerance, not exact floating-point equality.

## Report navigation

1. **Executive overview:** sales, profit, margin, orders and delivery reliability.
2. **Sales and profitability:** discounts, monthly profit, basket value and category economics.
3. **Delivery performance:** actual versus scheduled days, late-rate trends and market/mode comparison.
4. **Markets and destinations:** region contribution and an expandable market → country → city matrix.
5. **Customers and products:** customer mix, category treemap, portfolio scatter and margin/discount comparison.
6. **Order explorer:** order-level investigation and status-based financial subtotals.
7. **Business insights:** a written full-dataset baseline with recommended management actions.

Use the year, market, shipping-mode and customer-segment slicers on each analytical page. The written business-insights page is explicitly a fixed baseline; it does not change with selections.
