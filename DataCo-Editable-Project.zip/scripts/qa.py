from pathlib import Path
import pandas as pd,json
d=pd.read_pickle('work/data.pkl');o=pd.read_pickle('work/orders.pkl')
eligible=o[o.delivery!='Shipping canceled'];late=o[o.delivery=='Late delivery']
checks={'source_rows':len(d),'unique_item_ids':d['Order Item Id'].nunique(),'orders':len(o),'customers':d['Order Customer Id'].nunique(),'gross_sales':float(d.Sales.sum()),'net_booked_sales':float(d['Order Item Total'].sum()),'recorded_profit':float(d['Benefit per order'].sum()),'recorded_margin':float(d['Benefit per order'].sum()/d['Order Item Total'].sum()),'discount_value':float(d['Order Item Discount'].sum()),'delivery_eligible_orders':len(eligible),'late_orders':len(late),'late_delivery_rate':len(late)/len(eligible),'canceled_shipments':int((o.delivery=='Shipping canceled').sum()),'loss_making_orders':int((o.profit<0).sum()),'timestamp_elapsed_day_disagreements':int(((d.ShippingDate-d.OrderDate).dt.total_seconds()/86400!=d['Days for shipping (real)']).sum()),'date_min':str(d.OrderDate.min()),'date_max':str(d.OrderDate.max())}
assert len(d)==d['Order Item Id'].nunique()
assert len(eligible)+checks['canceled_shipments']==len(o)
assert abs(checks['recorded_profit']-o.profit.sum())<0.01
assert abs(checks['net_booked_sales']-o.net.sum())<0.01
assert (d['Benefit per order']==d['Order Profit Per Order']).all()
assert (d['Sales per customer']==d['Order Item Total']).all()
Path('outputs/DataCo Supply Chain/Metric Reconciliation.json').write_text(json.dumps(checks,indent=2),encoding='utf-8')
print(json.dumps(checks,indent=2))
