from pathlib import Path
import math,json,zipfile
import pandas as pd
from reportlab.pdfgen import canvas
from reportlab.lib.colors import HexColor,Color,white
from reportlab.lib.pagesizes import A4,landscape
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import Paragraph
from reportlab.lib.styles import ParagraphStyle
from xml.sax.saxutils import escape
out=Path('outputs/DataCo Print Report');out.mkdir(parents=True,exist_ok=True)
pdfmetrics.registerFont(TTFont('Segoe',r'C:\Windows\Fonts\segoeui.ttf'))
pdfmetrics.registerFont(TTFont('SegoeBold',r'C:\Windows\Fonts\segoeuib.ttf'))
d=pd.read_pickle('work/data.pkl');o=pd.read_pickle('work/orders.pkl')
extra=d.groupby('Order Id').agg(region=('Order Region','first'),city=('Order City','first'),state=('Order State','first'),segment=('Customer Segment','first'),customer=('Order Customer Id','first'),shipdate=('ShippingDate','first'))
o=o.join(extra);eligible=o[o.delivery!='Shipping canceled']
navy='#142D46';teal='#167D9A';light='#F2F5FA';muted='#526579';red='#BB4F4F';gold='#B07C23'
W,H=landscape(A4);M=36;CW=W-2*M
class Numbered(canvas.Canvas):
 def __init__(self,*a,**kw):super().__init__(*a,**kw);self.states=[]
 def showPage(self):self.states.append(dict(self.__dict__));self._startPage()
 def save(self):
  total=len(self.states)
  for s in self.states:
   self.__dict__.update(s);self.setFillColor(HexColor(muted));self.setFont('Segoe',8)
   self.drawString(M,20,'DataCo | Historical snapshot | Monetary values in undocumented source currency')
   self.drawRightString(W-M,20,f'{self._pageNumber} / {total}');super().showPage()
  super().save()
c=Numbered(str(out/'DataCo Print Report.pdf'),pagesize=(W,H));c.setTitle('DataCo Supply Chain - Print Report');c.setAuthor('Business Analytics')
styles={s:ParagraphStyle(s,fontName='Segoe',fontSize=n,leading=n*1.4,textColor=HexColor(navy)) for s,n in [('body',10),('small',8.5),('note',9)]}
def para(txt,x,y,w,style='body'):
 p=Paragraph(txt,styles[style]);_,h=p.wrap(w,1000);p.drawOn(c,x,y-h);return h
def start(title,sub):
 c.setFillColor(HexColor(navy));c.rect(0,H-10,W,10,fill=1,stroke=0)
 c.setFont('SegoeBold',9);c.drawString(M,H-33,'DATACO / SUPPLY CHAIN INTELLIGENCE')
 c.setFont('SegoeBold',23);c.drawString(M,H-66,title)
 para(sub,M,H-79,CW,'small')
 c.setStrokeColor(HexColor('#DCE4ED'));c.line(M,H-107,W-M,H-107)
def end():c.showPage()
def insight(txt,y=90,h=48):
 c.setFillColor(HexColor(light));c.roundRect(M,y-h,CW,h,7,fill=1,stroke=0);para(txt,M+12,y-9,CW-24,'note')
def fmt(v,kind='num'):
 if pd.isna(v):return '-'
 if kind=='pct':return f'{v:.1%}'
 if kind=='money':return f'{v:,.0f}'
 if kind=='dec':return f'{v:,.2f}'
 return f'{int(v):,}'
def compact(v):return f'{v/1e6:.2f}M' if abs(v)>=1e6 else f'{v/1e3:.0f}K' if abs(v)>=1e3 else f'{v:.0f}'
def kpis(vals,y=H-128):
 width=(CW-12*(len(vals)-1))/len(vals)
 for i,(label,value) in enumerate(vals):
  x=M+i*(width+12);c.setFillColor(HexColor(light));c.roundRect(x,y-67,width,67,5,fill=1,stroke=0)
  c.setFillColor(HexColor(muted));c.setFont('Segoe',9);c.drawString(x+10,y-17,label)
  c.setFillColor(HexColor(navy));c.setFont('SegoeBold',23);c.drawString(x+10,y-48,value)
def bars(title,series,x,y,w,h,percent=False,barcolor=teal):
 c.setFillColor(HexColor(navy));c.setFont('SegoeBold',12);c.drawString(x,y,title)
 n=len(series);labelw=min(142,w*.38);plotw=w-labelw-48;step=(h-30)/max(n,1);mx=max(float(v) for _,v in series) or 1
 for i,(label,val) in enumerate(series):
  yy=y-30-i*step;c.setFont('Segoe',9);c.setFillColor(HexColor(muted));label=str(label)
  if pdfmetrics.stringWidth(label,'Segoe',9)>labelw-14:
   while pdfmetrics.stringWidth(label+'...','Segoe',9)>labelw-14:label=label[:-1]
   label+='...'
  c.drawRightString(x+labelw-9,yy+2,label)
  c.setFillColor(HexColor(barcolor));c.roundRect(x+labelw,yy-2,max(1,plotw*float(val)/mx),min(12,step*.55),2,fill=1,stroke=0)
  c.setFillColor(HexColor(navy));c.setFont('Segoe',8.5);c.drawString(x+labelw+plotw*float(val)/mx+5,yy+1,f'{val:.1%}' if percent else compact(float(val)))
def line(title,series,x,y,w,h,kind='money',col=teal):
 c.setFillColor(HexColor(navy));c.setFont('SegoeBold',12);c.drawString(x,y,title)
 left=x+50;bottom=y-h+30;pw=w-80;ph=h-65;values=[float(v) for v in series.values];mx=max(values)*1.12;mn=0
 for i in range(5):
  yy=bottom+ph*i/4;c.setStrokeColor(HexColor('#DFE6ED'));c.line(left,yy,left+pw,yy)
  c.setFillColor(HexColor(muted));c.setFont('Segoe',8);c.drawRightString(left-8,yy-3, f'{mx*i/4:.0%}' if kind=='pct' else compact(mx*i/4))
 pts=[]
 for i,(label,v) in enumerate(series.items()):
  xx=left+pw*i/max(len(series)-1,1);yy=bottom+ph*(float(v)-mn)/(mx-mn);pts.append((xx,yy))
  if i%6==0 or i==len(series)-1:
   c.setFillColor(HexColor(muted));c.setFont('Segoe',8);c.drawCentredString(xx,bottom-16,str(label))
 p=c.beginPath();p.moveTo(*pts[0])
 for xx,yy in pts[1:]:p.lineTo(xx,yy)
 c.setStrokeColor(HexColor(col));c.setLineWidth(2);c.drawPath(p)
 c.setFillColor(HexColor(col));c.circle(*pts[-1],3,fill=1,stroke=0)
 c.setFont('SegoeBold',9);c.drawRightString(left+pw, min(y-25,pts[-1][1]+12),fmt(values[-1],'pct') if kind=='pct' else fmt(values[-1],'money'))
def table(headers,rows,widths,y=H-137,rowheight=23):
 x=M;headerh=38;c.setFillColor(HexColor(navy));c.rect(x,y-headerh,sum(widths),headerh,fill=1,stroke=0)
 for header,w in zip(headers,widths):
  p=Paragraph(escape(header),ParagraphStyle('th',fontName='SegoeBold',fontSize=9,leading=11,textColor=white));_,hh=p.wrap(w-14,headerh-6);p.drawOn(c,x+7,y-(headerh+hh)/2);x+=w
 for i,row in enumerate(rows):
  yy=y-headerh-(i+1)*rowheight
  if i%2==0:c.setFillColor(HexColor(light));c.rect(M,yy,sum(widths),rowheight,fill=1,stroke=0)
  x=M
  for j,(cell,w) in enumerate(zip(row,widths)):
   p=Paragraph(escape(str(cell)),ParagraphStyle('td',fontName='Segoe',fontSize=8.5,leading=10,textColor=HexColor(navy),alignment=0 if j==0 else 2))
   _,hh=p.wrap(w-14,rowheight-4)
   if hh>rowheight-2:raise ValueError(f'Cell overflow: {cell}')
   p.drawOn(c,x+7,yy+(rowheight-hh)/2);x+=w
 return y-headerh-len(rows)*rowheight
def aggregate(frame,key):
 a=frame.groupby(key,dropna=False).agg(orders=('Order Id','nunique'),sales=('Order Item Total','sum'),profit=('Benefit per order','sum'),gross=('Sales','sum'),discount=('Order Item Discount','sum'),units=('Order Item Quantity','sum'))
 e=frame[frame['Delivery Status']!='Shipping canceled'].groupby(key,dropna=False)['Order Id'].nunique()
 l=frame[frame['Delivery Status']=='Late delivery'].groupby(key,dropna=False)['Order Id'].nunique()
 a['eligible']=e.reindex(a.index).fillna(0);a['late']=l.reindex(a.index).fillna(0);a['late_rate']=a.late/a.eligible.replace(0,float('nan'));a['margin']=a.profit/a.sales;a['discount_rate']=a.discount/a.gross
 return a.sort_values('sales',ascending=False)
market=aggregate(d,'Market');regions=aggregate(d,'Order Region');cats=aggregate(d,'Category Name');products=aggregate(d,'Product Name');countries=aggregate(d,'Order Country');seg=aggregate(d,'Customer Segment');monthly=o.groupby(o.date.dt.to_period('M')).agg(orders=('net','size'),sales=('net','sum'),profit=('profit','sum'))
monthly['aov']=monthly.sales/monthly.orders
net=float(d['Order Item Total'].sum());profit=float(d['Benefit per order'].sum());late=int(eligible.late.sum());rate=late/len(eligible)
# 01
start('01  Executive overview','Scope: all markets, shipping modes, customer segments and order statuses | 01 Jan 2015 - 31 Jan 2018')
kpis([('Net booked sales',compact(net)),('Recorded profit',compact(profit)),('Recorded margin',f'{profit/net:.1%}'),('Distinct orders',f'{len(o):,}'),('Late delivery rate',f'{rate:.1%}')])
line('Net sales - full monthly history',monthly.sales,M,H-224,CW,185)
insight('<b>Management focus.</b> Positive aggregate profit coexists with weak delivery reliability and a sharp late-period reduction in basket value. Validate delivery commitments and the source/product-mix change before attributing causes.',y=116,h=63)
end()
# 02
start('02  Sales, volume and basket value','Monthly history is shown in full. January 2018 is compared with January 2017, not with a full prior year.')
line('Orders per month',monthly.orders,M,H-135,CW,162,kind='num')
line('Average order value after discounts',monthly.aov,M,H-310,CW,162,kind='money',col=gold)
insight('<b>January comparison.</b> Orders rose 21.7% to 2,123, while net sales fell 67.8% to 0.30M. Average order value fell from 530.36 to 140.35. Investigate product mix, quantities and source completeness.',y=77,h=39)
end()
# 03
start('03  Profitability and discount exposure','Recorded benefit includes only costs represented in the source. Financial totals include all order statuses.')
kpis([('Gross sales',compact(d.Sales.sum())),('Discount value',compact(d['Order Item Discount'].sum())),('Weighted discount',fmt(d['Order Item Discount'].sum()/d.Sales.sum(),'pct')),('Loss-making orders',f'{(o.profit<0).sum():,}'),('Loss-making rate',fmt((o.profit<0).mean(),'pct'))])
bars('Top 10 categories by net sales',list(cats.sales.head(10).items()),M,H-225,CW*.52,220)
rows=[[n,fmt(r.sales,'money'),fmt(r.margin,'pct')] for n,r in cats.head(10).iterrows()]
# table on right using temporary translated canvas origin
c.saveState();c.translate(CW*.54,0);table(['Category','Net sales','Margin'],rows,[135,125,94],y=H-220,rowheight=20);c.restoreState()
insight('<b>Loss exposure.</b> 13,909 whole orders had negative total benefit, contributing -2.62M. An item loss does not necessarily make the whole basket unprofitable. Discounts and lateness are associations, not established causes.',y=100,h=55)
end()
# 04
start('04  Delivery reliability','Distinct orders | Late rate excludes Shipping canceled | Early and on-time deliveries both meet the scheduled window')
kpis([('Eligible orders',f'{len(eligible):,}'),('Late orders',f'{late:,}'),('Late rate',fmt(rate,'pct')),('On-time or early',fmt(1-rate,'pct')),('Mean late delay','1.62 days')])
mode=eligible.groupby('mode').agg(orders=('net','size'),late=('late','sum'),actual=('real','mean'),scheduled=('scheduled','mean'));mode['rate']=mode.late/mode.orders
rows=[[n,fmt(r.orders),fmt(r.late),fmt(r.rate,'pct'),fmt(r.actual,'dec'),fmt(r.scheduled,'dec')] for n,r in mode.sort_values('rate',ascending=False).iterrows()]
table(['Shipping mode','Eligible orders','Late orders','Late rate','Actual days','Scheduled days'],rows,[160,125,115,105,130,CW-635],y=H-223,rowheight=32)
insight('<b>The promise matters.</b> First Class averages 2 actual days against a 1-day commitment, while Standard Class averages about 4 days against a 4-day commitment. First Class is faster in elapsed time but less reliable against its promised window.',y=123,h=69)
end()
#05
start('05  Delivery by market and mode','Rates use noncanceled orders. Counts are shown separately so a high rate can be assessed against its volume.')
modes=['First Class','Second Class','Same Day','Standard Class'];markets=list(market.index)
rows=[]
for mk in markets:
 ee=eligible[eligible.market==mk];row=[mk]
 for md in modes:
  z=ee[ee['mode']==md];row.append(fmt(z.late.mean(),'pct'))
 rows.append(row)
table(['Market']+modes,rows,[160]+[(CW-160)/4]*4,y=H-133,rowheight=33)
rows2=[]
for mk in markets:
 ee=eligible[eligible.market==mk];rows2.append([mk]+[fmt(len(ee[ee['mode']==md])) for md in modes])
table(['Eligible order counts']+modes,rows2,[160]+[(CW-160)/4]*4,y=H-350,rowheight=24)
end()
#06
start('06  Destination regions - complete view','All destination regions are shown. Order geography represents the delivery destination; customer/store coordinates are not used.')
items=list(regions.sales.items());mid=math.ceil(len(items)/2)
bars('Regions ranked by net sales',items[:mid],M,H-140,CW/2-15,310)
bars('Remaining destination regions',items[mid:],M+CW/2+15,H-140,CW/2-15,310)
insight('<b>Route prioritization.</b> Compare volume, value and delivery reliability together. An extreme rate in a small location should not carry the same operational weight as a recurring issue on a major route.',y=95,h=48)
end()
#07
start('07  Destination markets','Fixed market summary replaces the interactive hierarchy. Every country is listed in the appendix; city-level detail is supplied in CSV.')
rows=[[n,fmt(r.orders),fmt(r.sales,'money'),fmt(r.profit,'money'),fmt(r.margin,'pct'),fmt(r.late_rate,'pct')] for n,r in market.iterrows()]
table(['Market','Orders','Net sales','Recorded profit','Margin','Late rate'],rows,[150,90,150,150,110,CW-650],rowheight=35)
insight('<b>Commercial concentration.</b> Europe and LATAM generated 9.77M and 9.24M respectively, together about 57.5% of net booked sales. Late-associated sales total 18.08M; this is affected business volume, not measured lost revenue.',y=177,h=72)
end()
#08
start('08  Customers and product portfolio','Customer and product summaries are static and fully labeled. Complete category and product rankings follow in the appendix.')
rows=[[n,fmt(r.orders),fmt(r.sales,'money'),fmt(r.margin,'pct'),fmt(r.late_rate,'pct')] for n,r in seg.iterrows()]
table(['Customer segment','Orders','Net sales','Margin','Late rate'],rows,[180,125,185,140,CW-630],rowheight=30)
bars('Top 8 products by net sales',list(products.sales.head(8).items()),M,H-290,CW,178)
insight('<b>Portfolio focus.</b> Fishing is the largest category: 6.23M net sales and 0.76M recorded profit. Assess sales size and margin together. Complete product/category tables avoid reliance on hover tooltips.',y=77,h=39)
end()
#09
start('09  Order exceptions for review','Deliberate selection: 10 orders with the most negative whole-order recorded profit. This is not the full order population.')
worst=o.sort_values('profit').head(10)
rows=[[str(idx),r.date.strftime('%d %b %Y'),r.country,fmt(r.net,'money'),fmt(r.profit,'money'),r.delivery] for idx,r in worst.iterrows()]
table(['Order ID','Order date','Destination country','Net sales','Recorded profit','Delivery status'],rows,[78,102,180,102,117,CW-579],rowheight=26)
insight('<b>Complete investigation data.</b> Orders - Full Detail.csv contains all 65,752 orders, including destination, status, mode and elapsed-day fields. Use it for sorting/filtering; the PDF presents a review shortlist rather than thousands of pages.',y=108,h=61)
end()
#10
start('10  Business insights and next actions','Full-dataset management brief | Historical snapshot | Findings are descriptive and require operational validation')
texts=[('1. Review delivery commitments','All 9,602 eligible First Class orders missed the scheduled window. Check promise definitions, processing milestones and carrier delivery records before changing the shipping mix.'),('2. Reconcile the late-period commercial shift','Higher order counts coincide with lower sales and basket values from late 2017. Validate extract completeness, product availability and basket composition before calling it a demand decline.'),('3. Investigate negative-benefit orders','21.2% of whole orders have a negative recorded benefit. Review loss concentration and product/discount composition; distinguish item-level loss from full-basket profitability.'),('4. Start where commercial exposure is largest','Europe, LATAM and the Fishing category carry substantial value. Prioritize high-volume routes and material loss exposures while retaining sample-size checks.'),('5. Agree the data definitions','Confirm source currency, recognized-revenue rules and an independent arrival timestamp. Pending orders already carry delivery labels; this is not a validated live tracking feed.')]
y=H-139
for heading,body in texts:
 c.setFillColor(HexColor(teal));c.setFont('SegoeBold',12);c.drawString(M,y,heading);hh=para(escape(body),M,y-13,CW);y-=hh+42
end()
#11
start('11  Definitions and interpretation limits','Consistent with the Power BI report | Financial values use source units | Scope is not altered by interactive selections')
definitions=[('Financial basis','Gross Sales = sum of Sales. Net Booked Sales = sum of Order Item Total. Recorded Profit = sum of Benefit per order. Margin = total profit / total net booked sales. All order statuses are included.'),('Order and item grain','Each source row is one order item. Orders use distinct Order ID; shipping-day averages count each order once. Product/category order counts overlap and must not be added to get the overall order total.'),('Delivery basis','Exclude Shipping canceled from late-rate denominators. Count late orders by the source Delivery Status. Same Day has a zero-day scheduled window. Late-associated sales are exposure, not a loss estimate.'),('No verified arrival date','The source has order and shipping timestamps but no separate confirmed arrival date. Timestamp elapsed days disagree with the actual-day field for 9,737 items (5.4%); no arrival timestamp is invented.'),('Source quality','Benefit per order equals Order Profit Per Order, and Sales per customer equals Order Item Total. Duplicate aliases are not summed. Product Description is entirely missing; Order Zipcode is about 86.2% missing.'),('Currency, status and causality','Currency, carrier, freight cost and full cost definitions are absent. Closed/complete values are status subtotals, not confirmed accounting revenue. Observed associations do not establish causes.'),('Snapshot and source','Source: DataCoSupplyChainDataset.csv, original full extract, 180,519 items and 65,752 orders. Period: 01 Jan 2015 - 31 Jan 2018. Monetary values are rounded for printing; companion CSVs retain more precision.')]
y=H-137
for title,txt in definitions:
 hh=para('<b>'+title+'.</b> '+escape(txt),M,y,CW,'note');y-=hh+17
end()
# Appendices, complete rows, fixed pagination
coverage={}
def appendix(title,frame,headers,colspec,widths,rowsper=30):
 rows=[]
 for idx,r in frame.iterrows():rows.append([str(idx)]+[fmt(r[col],typ) for col,typ in colspec])
 for startrow in range(0,len(rows),rowsper):
  chunk=rows[startrow:startrow+rowsper];start(title,f'Complete ranking | Rows {startrow+1}-{startrow+len(chunk)} of {len(rows)} | All source statuses | Order counts within categories/products overlap')
  table(headers,chunk,widths,rowheight=13 if title.startswith('D') else 14)
  end()
 coverage[title]=len(rows)
appendix('A  Country performance',countries,['Destination country','Orders','Net sales','Profit','Margin','Late rate'],[('orders','num'),('sales','money'),('profit','money'),('margin','pct'),('late_rate','pct')],[230,85,130,130,90,CW-665],rowsper=26)
appendix('B  Category performance',cats,['Category','Orders','Net sales','Profit','Margin','Discount rate'],[('orders','num'),('sales','money'),('profit','money'),('margin','pct'),('discount_rate','pct')],[230,85,130,130,90,CW-665],rowsper=26)
appendix('C  Product performance',products,['Product','Units','Net sales','Profit','Margin'],[('units','num'),('sales','money'),('profit','money'),('margin','pct')],[340,80,135,135,CW-690],rowsper=26)
appendix('D  Monthly financial detail',monthly,['Order month','Orders','Net sales','Profit','Avg. order value'],[('orders','num'),('sales','money'),('profit','money'),('aov','dec')],[180,115,170,160,CW-625],rowsper=26)
c.save()
# Full detail companions contain no names, addresses or customer coordinates.
orderexport=o.reset_index().rename(columns={'Order Id':'Order ID','net':'Net Booked Sales','profit':'Recorded Profit','late':'Late Flag','delivery':'Delivery Status','mode':'Shipping Mode','real':'Actual Days','scheduled':'Scheduled Days','date':'Order Date','market':'Market','country':'Destination Country','status':'Order Status','region':'Destination Region','city':'Destination City','state':'Destination State','segment':'Customer Segment','customer':'Customer ID','shipdate':'Shipping Timestamp','lines':'Item Count'})
orderexport.to_csv(out/'Orders - Full Detail.csv',index=False,encoding='utf-8-sig')
city=aggregate(d,['Order Country','Order State','Order City']);city.to_csv(out/'Destinations - Full City Detail.csv',encoding='utf-8-sig')
for name,frame in [('Countries',countries),('Categories',cats),('Products',products),('Monthly',monthly)]:frame.to_csv(out/f'{name} - Full Detail.csv',encoding='utf-8-sig')
(out/'Read Me.txt').write_text('PRINT EDITION\n\nThis PDF is rebuilt from the original full CSV, not from screenshots of clipped Power BI visuals. It has no interactive slicers, drill controls, hover dependencies or scrollbars. The PDF contains all monthly, region, market, country, category and product summaries. Countries/categories/products are deliberately paginated. Order review shows the 10 most negative-profit orders; all 65,752 orders and all destination-city groups are provided in companion CSVs.\n\nScope: all statuses and all markets, 01 Jan 2015 - 31 Jan 2018. Net booked sales are not recognized revenue. Late rates exclude Shipping canceled. Currency is undocumented.\n\nThe existing PBIX remains the interactive edition. This is a separately generated print edition, not a modified PBIX. For a future native scheduled printable report, use Power BI Report Builder/paginated reports with the same approved measure definitions.\n',encoding='utf-8')
print('PDF CREATED',len(c.states),'pages; appendix coverage',coverage,'city groups',len(city),'orders',len(orderexport))
