from pathlib import Path
import pandas as pd,json,uuid,shutil
root=Path('outputs/DataCo Report');root.mkdir(parents=True,exist_ok=True)
report=root/'DataCo.Report';model=root/'DataCo.SemanticModel';defs=report/'definition'
def save(p,v):
 p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,indent=2,ensure_ascii=False),encoding='utf-8')
base='https://developer.microsoft.com/json-schemas/fabric/item/report/definition/'
save(root/'DataCo.pbip',{'$schema':'https://developer.microsoft.com/json-schemas/fabric/pbip/pbipProperties/1.0.0/schema.json','version':'1.0','artifacts':[{'report':{'path':'DataCo.Report'}}],'settings':{'enableAutoRecovery':True}})
save(report/'definition.pbir',{'$schema':'https://developer.microsoft.com/json-schemas/fabric/item/report/definitionProperties/2.0.0/schema.json','version':'4.0','datasetReference':{'byPath':{'path':'../DataCo.SemanticModel'}}})
save(model/'definition.pbism',{'$schema':'https://developer.microsoft.com/json-schemas/fabric/item/semanticModel/definitionProperties/1.0.0/schema.json','version':'1.0','settings':{}})
fields={
 'Order Item Id':('Item ID','int64'),'Order Id':('Order ID','int64'),'Order Customer Id':('Customer ID','int64'),
 'Sales':('Gross Sales Amount','double'),'Order Item Total':('Net Sales','double'),'Benefit per order':('Profit','double'),
 'Order Item Discount':('Discount','double'),'Order Item Discount Rate':('Discount Rate','double'),'Order Item Quantity':('Quantity','int64'),
 'Days for shipping (real)':('Actual Days','int64'),'Days for shipment (scheduled)':('Scheduled Days','int64'),
 'Late_delivery_risk':('Late Flag','int64'),'Shipping Mode':('Shipping Mode','string'),'Delivery Status':('Delivery Status','string'),
 'Order Status':('Order Status','string'),'Market':('Market','string'),'Order Region':('Destination Region','string'),
 'Order Country':('Destination Country','string'),'Order State':('Destination State','string'),'Order City':('Destination City','string'),
 'Customer Country':('Customer Country','string'),'Customer City':('Customer City','string'),'Customer Segment':('Customer Segment','string'),
 'Category Name':('Category','string'),'Department Name':('Department','string'),'Product Name':('Product','string'),'Type':('Payment Type','string'),
 'order date (DateOrders)':('Order Timestamp','dateTime'),'shipping date (DateOrders)':('Shipping Timestamp','dateTime')}
def mq(s):return '"'+s.replace('"','""')+'"'
types={'int64':'Int64.Type','double':'type number','string':'type text','dateTime':'type datetime'}
selected=', '.join(mq(s) for s in fields)
renames=', '.join('{'+mq(s)+', '+mq(n)+'}' for s,(n,t) in fields.items())
typed=', '.join('{'+mq(n)+', '+types[t]+'}' for n,t in fields.values())
query=f'''let
 Source = Csv.Document(File.Contents("E:\\Analysis project supply chain\\raw data\\DataCoSupplyChainDataset.csv"),[Delimiter=",",Columns=51,Encoding=1252,QuoteStyle=QuoteStyle.Csv]),
 Headers = Table.PromoteHeaders(Source,[PromoteAllScalars=true]),
 Selected = Table.SelectColumns(Headers,{{{selected}}}),
 Renamed = Table.RenameColumns(Selected,{{{renames}}}),
 Typed = Table.TransformColumnTypes(Renamed,{{{typed}}},"en-US"),
 OrderDate = Table.AddColumn(Typed,"Order Date",each Date.From([Order Timestamp]),type date),
 ShippingDate = Table.AddColumn(OrderDate,"Shipping Date",each Date.From([Shipping Timestamp]),type date),
 Delay = Table.AddColumn(ShippingDate,"Delay Days",each Number.Max(0,[Actual Days]-[Scheduled Days]),Int64.Type),
 CityLabel = Table.AddColumn(Delay,"Destination",each [Destination City] & ", " & [Destination Country],type text),
 OrderMonth = Table.AddColumn(CityLabel,"Order Month",each Date.ToText([Order Date],"yyyy-MM"),type text),
 OrderYear = Table.AddColumn(OrderMonth,"Order Year",each Date.Year([Order Date]),Int64.Type)
in OrderYear'''.replace('Number.Max(0,[Actual Days]-[Scheduled Days])','List.Max({0,[Actual Days]-[Scheduled Days]})')
(root/'Power Query.m').write_text(query,encoding='utf-8')
measures=[]
def m(n,e,f='#,0.00',folder='Commercial',description=None):
 measures.append({'name':n,'expression':e,'formatString':f,'displayFolder':folder,'description':description or n})
m('Gross Sales','SUM(Fact[Gross Sales Amount])')
m('Net Booked Sales','SUM(Fact[Net Sales])',description='Recorded item value after discounts, across every order status; not recognized revenue.')
m('Recorded Profit','SUM(Fact[Profit])',description='Sum of item-level recorded benefit, across every order status; excludes unrecorded costs.')
m('Recorded Margin','DIVIDE([Recorded Profit], [Net Booked Sales])','0.0%')
m('Discount Value','SUM(Fact[Discount])')
m('Weighted Discount Rate','DIVIDE([Discount Value], [Gross Sales])','0.0%')
m('Orders','DISTINCTCOUNT(Fact[Order ID])','#,0','Volume')
m('Order Items','COUNTROWS(Fact)','#,0','Volume')
m('Units','SUM(Fact[Quantity])','#,0','Volume')
m('Customers','DISTINCTCOUNT(Fact[Customer ID])','#,0','Volume')
m('Average Order Value','DIVIDE([Net Booked Sales],[Orders])')
m('Profit per Order','DIVIDE([Recorded Profit],[Orders])')
m('Items per Order','DIVIDE([Order Items],[Orders])','0.00','Volume')
m('Orders per Customer','DIVIDE([Orders],[Customers])','0.00','Volume')
m('Closed or Complete Sales','CALCULATE([Net Booked Sales],Fact[Order Status] IN {"CLOSED","COMPLETE"})',description='Status-based subtotal only; neither accounting revenue nor proof of cash settlement.')
m('Canceled or Fraud Sales','CALCULATE([Net Booked Sales],Fact[Order Status] IN {"CANCELED","SUSPECTED_FRAUD"})')
m('Loss-making Orders','COUNTROWS(FILTER(VALUES(Fact[Order ID]),CALCULATE([Recorded Profit]) < 0))','#,0','Profitability',description='Orders whose selected item profit sums below zero in current filter context.')
m('Loss-making Order Rate','DIVIDE([Loss-making Orders],[Orders])','0.0%','Profitability')
m('Negative Item Profit','CALCULATE([Recorded Profit],Fact[Profit]<0)','#,0.00','Profitability')
m('Profitable Item Contribution','CALCULATE([Recorded Profit],Fact[Profit]>=0)','#,0.00','Profitability')
m('Loss Item Rate','DIVIDE(CALCULATE([Order Items],Fact[Profit]<0),[Order Items])','0.0%','Profitability')
m('Delivery Eligible Orders','CALCULATE([Orders],KEEPFILTERS(Fact[Delivery Status]<>"Shipping canceled"))','#,0','Delivery')
m('Late Orders','CALCULATE([Orders],KEEPFILTERS(Fact[Delivery Status]="Late delivery"))','#,0','Delivery')
m('Late Delivery Rate','DIVIDE([Late Orders],[Delivery Eligible Orders])','0.0%','Delivery')
m('On-time or Early Orders','CALCULATE([Orders],KEEPFILTERS(Fact[Delivery Status] IN {"Advance shipping","Shipping on time"}))','#,0','Delivery')
m('On-time or Early Rate','DIVIDE([On-time or Early Orders],[Delivery Eligible Orders])','0.0%','Delivery')
m('Canceled Shipments','CALCULATE([Orders],KEEPFILTERS(Fact[Delivery Status]="Shipping canceled"))','#,0','Delivery')
m('Shipment Cancellation Rate','DIVIDE([Canceled Shipments],[Orders])','0.0%','Delivery')
m('Average Actual Days','AVERAGEX(VALUES(Fact[Order ID]),CALCULATE(MAX(Fact[Actual Days])))','0.00','Delivery')
m('Average Scheduled Days','AVERAGEX(VALUES(Fact[Order ID]),CALCULATE(MAX(Fact[Scheduled Days])))','0.00','Delivery')
m('Average Late Delay','CALCULATE(AVERAGEX(VALUES(Fact[Order ID]),CALCULATE(MAX(Fact[Delay Days]))),KEEPFILTERS(Fact[Delivery Status]="Late delivery"))','0.00','Delivery')
m('Late-associated Sales','CALCULATE([Net Booked Sales],KEEPFILTERS(Fact[Delivery Status]="Late delivery"))','#,0.00','Delivery',description='Sales on late orders; this is exposure, not measured lost revenue.')
m('Net Sales Previous Year','CALCULATE([Net Booked Sales],DATEADD(\'Date\'[Date],-1,YEAR))','#,0.00','Time')
m('Net Sales YoY','DIVIDE([Net Booked Sales]-[Net Sales Previous Year],[Net Sales Previous Year])','0.0%','Time')
m('Profit Previous Year','CALCULATE([Recorded Profit],DATEADD(\'Date\'[Date],-1,YEAR))','#,0.00','Time')
m('Net Sales YTD','TOTALYTD([Net Booked Sales],\'Date\'[Date])','#,0.00','Time')
m('Period Label','FORMAT(MIN(Fact[Order Date]),"dd MMM yyyy") & " to " & FORMAT(MAX(Fact[Order Date]),"dd MMM yyyy")','','Context')
cols=[]
for n,t in list(fields.values())+[('Order Date','dateTime'),('Shipping Date','dateTime'),('Delay Days','int64'),('Destination','string'),('Order Month','string'),('Order Year','int64')]:
 c={'name':n,'dataType':t,'sourceColumn':n,'summarizeBy':'none'}
 if t=='dateTime':c['formatString']='dd MMM yyyy'
 if n=='Destination Country':c['dataCategory']='Country'
 if n=='Destination City':c['dataCategory']='City'
 if n in ['Item ID','Customer ID','Order Timestamp','Shipping Timestamp']:c['isHidden']=True
 cols.append(c)
datequery='''let
 Start = #date(2015,1,1), End = #date(2018,12,31),
 Dates = Table.FromList(List.Dates(Start,Duration.Days(End-Start)+1,#duration(1,0,0,0)),Splitter.SplitByNothing(),{"Date"}),
 Typed = Table.TransformColumnTypes(Dates,{{"Date",type date}}),
 Year = Table.AddColumn(Typed,"Year",each Date.Year([Date]),Int64.Type),
 Month = Table.AddColumn(Year,"Year Month",each Date.ToText([Date],"yyyy-MM"),type text),
 MonthName = Table.AddColumn(Month,"Month",each Date.ToText([Date],"MMM"),type text),
 MonthNo = Table.AddColumn(MonthName,"Month Number",each Date.Month([Date]),Int64.Type)
in MonthNo'''
datecols=[{'name':n,'dataType':t,'sourceColumn':n,'summarizeBy':'none',**({'formatString':'dd MMM yyyy'} if n=='Date' else {}),**({'sortByColumn':'Month Number'} if n=='Month' else {})} for n,t in [('Date','dateTime'),('Year','int64'),('Year Month','string'),('Month','string'),('Month Number','int64')]]
mdl={'name':'DataCo','compatibilityLevel':1567,'model':{'culture':'en-US','defaultPowerBIDataSourceVersion':'powerBI_V3','sourceQueryCulture':'en-US','dataAccessOptions':{'legacyRedirects':True,'returnErrorValuesAsNull':True},'tables':[{'name':'Fact','columns':cols,'measures':measures,'partitions':[{'name':'Fact','mode':'import','source':{'type':'m','expression':query.splitlines()}}]},{'name':'Date','dataCategory':'Time','columns':datecols,'partitions':[{'name':'Date','mode':'import','source':{'type':'m','expression':datequery.splitlines()}}]}],'relationships':[{'name':str(uuid.uuid4()),'fromTable':'Fact','fromColumn':'Order Date','toTable':'Date','toColumn':'Date','crossFilteringBehavior':'oneDirection'}],'annotations':[{'name':'PBI_QueryOrder','value':'["Fact","Date"]'},{'name':'__PBI_TimeIntelligenceEnabled','value':'0'}]}}
save(model/'model.bim',mdl)
save(defs/'version.json',{'$schema':base+'versionMetadata/1.0.0/schema.json','version':'2.0.0'})
save(defs/'report.json',{'$schema':base+'report/3.1.0/schema.json','themeCollection':{'baseTheme':{'name':'CY24SU06','reportVersionAtImport':{'visual':'1.8.0','report':'2.0.0','page':'1.3.0'},'type':'SharedResources'}},'settings':{'useStylableVisualContainerHeader':True}})
def lit(v):return {'expr':{'Literal':{'Value':str(v).lower() if isinstance(v,bool) else str(v) if isinstance(v,(int,float)) else "'"+str(v).replace("'","''")+"'"}}}
def color(v):return {'solid':{'color':lit(v)}}
def field(n,table='Fact',measure=True):return {('Measure' if measure else 'Column'):{'Expression':{'SourceRef':{'Entity':table}},'Property':n}}
def projection(n,table='Fact',measure=True):return {'field':field(n,table,measure),'queryRef':table+'.'+n,'nativeQueryRef':n}
counter=0
def visual(page,typ,title,x,y,w,h,roles=None,objects=None):
 global counter
 counter+=1;name=f'v{counter:04}'
 v={'visualType':typ,'visualContainerObjects':{'title':[{'properties':{'show':lit(True),'text':lit(title),'fontSize':lit(13),'fontColor':color('#142D46'),'bold':lit(True),'titleWrap':lit(True)}}],'background':[{'properties':{'show':lit(True),'color':color('#FFFFFF'),'transparency':lit(0)}}],'border':[{'properties':{'show':lit(True),'color':color('#E1E7EF'),'radius':lit(10)}}]}}
 if roles:v['query']={'queryState':{role:{'projections':[projection(*a) if isinstance(a,tuple) else projection(a) for a in arr]} for role,arr in roles.items()}}
 if objects:v['objects']=objects
 save(defs/'pages'/page/'visuals'/name/'visual.json',{'$schema':base+'visualContainer/2.1.0/schema.json','name':name,'position':{'x':x,'y':y,'width':w,'height':h,'z':counter,'tabOrder':counter},'visual':v})
def text(page,content,x,y,w,h,size=14,bg=False):
 paragraphs=[{'textRuns':[{'value':line,'textStyle':{'fontFamily':'Segoe UI','fontSize':f'{size}pt','color':'#142D46'}}]} for line in content.split('\n')]
 visual(page,'textbox','',x,y,w,h,objects={'general':[{'properties':{'paragraphs':paragraphs}}]})
def chart(page,typ,title,cat,vals,x,y,w=744,h=285,table='Fact',extra=None):
 roles={'Category':[(cat,table,False)],'Y':vals};roles.update(extra or {})
 visual(page,typ,title,x,y,w,h,roles,{'dataPoint':[{'properties':{'defaultColor':color('#167D9A')}}],'categoryAxis':[{'properties':{'minimumCategoryWidth':lit(10)}}]})
 path=defs/'pages'/page/'visuals'/f'v{counter:04}'/'visual.json';v=json.loads(path.read_text(encoding='utf-8'))
 v['visual']['query']['sortDefinition']={'sort':[{'field':field(cat,table,False) if typ=='lineChart' else field(vals[0]),'direction':'Ascending' if typ=='lineChart' else 'Descending'}],'isDefaultSort':False}
 save(path,v)
pages=[]
def page(name,title,subtitle,cards,slicers=True):
 pages.append(name)
 save(defs/'pages'/name/'page.json',{'$schema':base+'page/1.4.0/schema.json','name':name,'displayName':title,'displayOption':'FitToPage','height':1000,'width':1600,'objects':{'background':[{'properties':{'color':color('#F2F5FA'),'transparency':lit(0)}}]}})
 text(name,'DATACO  /  SUPPLY CHAIN INTELLIGENCE',30,15,1540,38,14)
 text(name,title.upper(),30,58,1540,54,26)
 text(name,subtitle,30,118,1540,52,12)
 if slicers:
  for i,(n,t) in enumerate([('Year','Date'),('Market','Fact'),('Shipping Mode','Fact'),('Customer Segment','Fact')]):
   visual(name,'slicer',n,30+i*388,180,376,66,{'Values':[(n,t,False)]},{'data':[{'properties':{'mode':lit('Dropdown')}}]})
 for i,n in enumerate(cards):
  width=(1540-16*(len(cards)-1))/len(cards)
  visual(name,'card',n,30+i*(width+16),265,width,110,{'Values':[n]}, {'labels':[{'properties':{'fontSize':lit(26),'color':color('#142D46'),'labelDisplayUnits':lit(1 if n in ['Orders','Customers','Order Items','Units','Late Orders','Delivery Eligible Orders','Canceled Shipments'] else 0)}}],'categoryLabels':[{'properties':{'show':lit(False)}}]})
 return name
p=page('Executive','01  Executive overview','Recorded order economics and delivery service | All statuses included in financial totals | Amounts in source units; currency is undocumented',['Net Booked Sales','Recorded Profit','Recorded Margin','Orders','Late Delivery Rate'])
chart(p,'lineChart','Sales trend: inspect the late-period decline','Year Month',['Net Booked Sales'],30,397,744,245,'Date')
chart(p,'clusteredBarChart','Net sales by destination market','Market',['Net Booked Sales'],810,397,760,245)
chart(p,'clusteredBarChart','Delivery performance against the promised window','Shipping Mode',['Late Delivery Rate'],30,662,744,245)
chart(p,'clusteredBarChart','Recorded profit by department','Department',['Recorded Profit'],810,662,760,245)
text(p,'Reading guide: compare sales with order value, then review delivery promises by mode. Cross-select charts to investigate a segment; use page slicers to narrow the period and market.',30,925,1540,58,12)
p=page('Commercial','02  Sales and profitability','Gross value, discounts, net booked sales and recorded benefit | Profit reflects only the costs embedded in the source',['Gross Sales','Discount Value','Net Booked Sales','Recorded Profit','Loss-making Order Rate'])
chart(p,'lineChart','Monthly recorded profit','Year Month',['Recorded Profit'],30,397,744,245,'Date')
chart(p,'lineChart','Order value trend: compare with order volume on Overview','Year Month',['Average Order Value'],810,397,760,245,'Date')
chart(p,'clusteredBarChart','Sales after discount by department','Department',['Net Booked Sales'],30,662,744,245)
visual(p,'scatterChart','Category economics: sales, margin and units',810,662,760,245,{'Category':[('Category','Fact',False)],'X':['Net Booked Sales'],'Y':['Recorded Margin'],'Size':['Units'],'Tooltips':['Recorded Profit','Loss Item Rate']})
text(p,'Loss-making orders use the sum of selected item profits within each order. Category or product selections therefore evaluate the selected portion of an order. Discount analysis shows association; it does not establish that discounting caused losses.',30,925,1540,58,12)
p=page('Delivery','03  Delivery performance','Late rate = late orders / orders with noncanceled shipments | Distinct orders avoid overweighting multi-item baskets',['Delivery Eligible Orders','Late Orders','Late Delivery Rate','On-time or Early Rate','Average Late Delay'])
chart(p,'clusteredBarChart','Late rate by shipping mode','Shipping Mode',['Late Delivery Rate'],30,397,744,245)
chart(p,'clusteredColumnChart','Actual versus scheduled days (order-weighted)','Shipping Mode',['Average Actual Days','Average Scheduled Days'],810,397,760,245)
chart(p,'lineChart','Delivery reliability over time','Year Month',['Late Delivery Rate'],30,662,744,245,'Date')
visual(p,'pivotTable','Service comparison by destination market and shipping mode',810,662,760,245,{'Rows':[('Market','Fact',False)],'Columns':[('Shipping Mode','Fact',False)],'Values':['Delivery Eligible Orders','Late Delivery Rate','Average Late Delay']})
text(p,'The source provides a shipping timestamp and elapsed-day fields, but no verified arrival timestamp. Same Day is late when actual days exceed zero. Late-associated sales indicate affected business volume, not proven lost revenue.',30,925,1540,58,12)
p=page('Destinations','04  Markets and destinations','Destination region, country and city describe where the order is sent | Customer/store coordinates are excluded from destination analysis',['Orders','Net Booked Sales','Recorded Margin','Late Delivery Rate','Late-associated Sales'])
chart(p,'clusteredBarChart','Net sales by destination region','Destination Region',['Net Booked Sales'],30,397,744,510)
visual(p,'pivotTable','Country performance: volume, value, margin and service',810,397,760,510,{'Rows':[('Market','Fact',False),('Destination Country','Fact',False),('Destination City','Fact',False)],'Values':['Orders','Net Booked Sales','Recorded Margin','Late Delivery Rate']})
text(p,'Expand the destination hierarchy from market to country and city. Prioritize high-volume routes with weak service; avoid ranking small locations by rate alone. Names are retained as recorded in the source and may use Spanish spellings.',30,925,1540,58,12)
p=page('CustomersProducts','05  Customers and products','Understand the customer mix and product economics | Orders containing selected products count once per order',['Customers','Orders per Customer','Units','Items per Order','Weighted Discount Rate'])
chart(p,'clusteredBarChart','Net sales by customer segment','Customer Segment',['Net Booked Sales'],30,397,744,245)
visual(p,'treemap','Category mix of net sales',810,397,760,245,{'Group':[('Category','Fact',False)],'Values':['Net Booked Sales'],'Tooltips':['Recorded Profit','Recorded Margin']})
visual(p,'scatterChart','Product portfolio: value, margin and volume',30,662,744,245,{'Category':[('Product','Fact',False)],'X':['Net Booked Sales'],'Y':['Recorded Margin'],'Size':['Units'],'Tooltips':['Recorded Profit','Loss Item Rate']})
visual(p,'pivotTable','Category contribution and discount exposure',810,662,760,245,{'Rows':[('Category','Fact',False)],'Values':['Net Booked Sales','Recorded Profit','Recorded Margin','Weighted Discount Rate','Loss Item Rate']})
text(p,'Sales and profit are recorded at item level even where the raw column names say “per order” or “per customer.” Equivalent duplicate columns are not added twice. Personal names, street addresses and customer coordinates are excluded.',30,925,1540,58,12)
p=page('OrderExplorer','06  Order explorer','Investigate operational exceptions and order economics | Totals include every status unless filtered',['Orders','Canceled Shipments','Shipment Cancellation Rate','Closed or Complete Sales','Canceled or Fraud Sales'])
visual(p,'tableEx','Order investigation: select an order or expand filters',30,397,1540,510,{'Values':[('Order ID','Fact',False),('Order Date','Fact',False),('Destination','Fact',False),('Order Status','Fact',False),('Delivery Status','Fact',False),('Shipping Mode','Fact',False),'Net Booked Sales','Recorded Profit','Average Actual Days','Average Scheduled Days']})
text(p,'Shipping canceled combines canceled and suspected-fraud order statuses in this dataset. Closed or complete sales are a status subtotal, not recognized accounting revenue. Use the filter pane for order status, product or destination.',30,925,1540,58,12)
p=page('Insights','07  Business insights','Full-dataset findings | 01 Jan 2015–31 Jan 2018 | These written findings are a fixed baseline and do not change with slicers',[],False)
d=pd.read_pickle('work/data.pkl');o=pd.read_pickle('work/orders.pkl');eligible=o[o.delivery!='Shipping canceled'];late=o[o.delivery=='Late delivery']
mode=eligible.groupby('mode').late.mean(); margin=d['Benefit per order'].sum()/d['Order Item Total'].sum()
text(p,'01  Delivery promises need a closer look\n'+f'{len(late):,} of {len(eligible):,} eligible orders were late ({len(late)/len(eligible):.1%}). First Class missed its promised window on {mode["First Class"]:.1%} of eligible orders, versus {mode["Standard Class"]:.1%} for Standard Class. First Class was faster in elapsed days, but less reliable against its shorter promise. Review the promised windows and fulfillment flow before changing the shipping mix.',30,190,744,235,15)
text(p,'02  More orders are not translating into more value\nNovember 2017–January 2018 shows rising order counts alongside falling sales and average order value. January sales declined about 67.8% against January 2017 while order count increased about 21.7%. Product mix, basket size and source completeness should be checked before describing this as a demand decline.',810,190,760,235,15)
text(p,'03  Positive total profit masks substantial loss exposure\n'+f'The dataset records 33.05 million in net booked sales and 3.97 million in profit, a {margin:.1%} margin. At the complete-order level, 13,909 orders had a negative total benefit, representing 21.2% of orders. Review loss concentration by product, discount band and order status; delivery lateness alone does not prove the cause of these losses.',30,445,744,235,15)
text(p,'04  Protect the largest sources of commercial value\nEurope generated 9.77 million in net booked sales, followed by LATAM at 9.24 million; together they account for about 57.5% of the total. Fishing is the largest category at 6.23 million in net sales and 0.76 million in recorded profit. Begin route and margin reviews in these areas, while retaining volume thresholds for smaller segments.',810,445,760,235,15)
text(p,'05  Management actions\n1. Validate First Class and Second Class delivery commitments against actual operating times.\n2. Reconcile the late-2017 product mix and basket-size shift with the source owner.\n3. Review negative-benefit orders and distinguish item losses from whole-order losses.\n4. Agree the business currency, recognized-revenue rules and a verified delivery-completion field.',30,700,1540,215,15)
text(p,'Evidence limits: historical snapshot; no carrier, freight cost, confirmed arrival date or documented currency. Pending orders still carry delivery labels. Insights are descriptive and should be validated with operations before attributing causes.',30,935,1540,50,12)
save(defs/'pages'/'pages.json',{'$schema':base+'pagesMetadata/1.0.0/schema.json','pageOrder':pages,'activePageName':pages[0]})
(root/'Measures.dax').write_text('\n\n'.join(x['name']+' =\n'+x['expression'] for x in measures),encoding='utf-8')
print('BUILT',len(pages),'pages',counter,'visuals',len(measures),'measures',root.resolve())
