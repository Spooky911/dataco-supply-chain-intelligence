import urllib.request,json
from pathlib import Path
from urllib.parse import urljoin
base='https://developer.microsoft.com/json-schemas/fabric/item/report/definition/'
urls=[base+x for x in ['visualContainer/2.1.0/schema.json','visualConfiguration/2.1.0/schema-embedded.json','page/1.4.0/schema.json','pagesMetadata/1.0.0/schema.json','report/3.1.0/schema.json','versionMetadata/1.0.0/schema.json']]
store={}
def get(u):
 if u in store:return
 s=json.load(urllib.request.urlopen(u,timeout=30));store[u]=s
 def scan(x):
  if isinstance(x,dict):
   for k,v in x.items():
    if k=='$ref' and not v.startswith('#'):get(urljoin(u,v).split('#')[0])
    else:scan(v)
  elif isinstance(x,list):
   for v in x:scan(v)
 scan(s)
for u in urls:
 try:get(u)
 except Exception as e:print(u,str(e))
Path('work/schemas.json').write_text(json.dumps(store),encoding='utf-8')
for u in urls:
 if u in store:
  s=store[u];print(u,'REQUIRED',s.get('required'),'PROPS',list(s.get('properties',{})))
v=store[urls[1]]
print(json.dumps({k:v['properties'][k] for k in ['query','objects','visualContainerObjects']},indent=2)[:15000])
print('DEFS',list(v.get('definitions',{})))
