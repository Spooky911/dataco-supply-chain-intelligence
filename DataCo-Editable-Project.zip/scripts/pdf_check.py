from PIL import Image,ImageDraw
from pathlib import Path
from pypdf import PdfReader
import pandas as pd,json
fs=sorted(Path('work/pdfs').glob('page-*.png'))
for k in range(0,len(fs),9):
 sheet=Image.new('RGB',(1800,1350),'#d7dce2');draw=ImageDraw.Draw(sheet)
 for j,p in enumerate(fs[k:k+9]):
  im=Image.open(p);im.thumbnail((588,416));x=(j%3)*600+6;y=(j//3)*450+22;sheet.paste(im,(x,y));draw.text((x,y-18),p.stem,fill='black')
 sheet.save('work/pdfs/contact'+str(k//9)+'.png')
r=PdfReader('outputs/DataCo Print Report/DataCo Print Report.pdf');text='\n'.join(p.extract_text() for p in r.pages)
assert len(r.pages)==27
assert '2018-01' in text
assert '33.05M' in text and '57.3%' in text
assert 'Rows 157-164 of 164' in text
assert 'Rows 105-118 of 118' in text
o=pd.read_csv('outputs/DataCo Print Report/Orders - Full Detail.csv');assert len(o)==65752;assert o['Order ID'].nunique()==65752
assert abs(o['Net Booked Sales'].sum()-33054402.380216613)<0.01
assert abs(o['Recorded Profit'].sum()-3966902.974050357)<0.01
print('Verified 27 pages, full appendix ranges, final month, headline figures, all 65,752 unique orders and reconciled amounts')
