import sys,json
sys.path.insert(0,'work/validation')
from jsonschema import Draft7Validator,RefResolver
from pathlib import Path
store=json.loads(Path('work/schemas.json').read_text())
errors=[];count=0
for p in Path('outputs/DataCo Report/DataCo.Report/definition').rglob('*.json'):
 d=json.loads(p.read_text(encoding='utf-8'));u=d.get('$schema')
 if u not in store:continue
 validator=Draft7Validator(store[u],resolver=RefResolver(u,store[u],store=store))
 for e in validator.iter_errors(d):errors.append((str(p),list(e.path),e.message))
 count+=1
print('Validated',count,'files; errors',len(errors))
for e in errors[:30]:print(e)
