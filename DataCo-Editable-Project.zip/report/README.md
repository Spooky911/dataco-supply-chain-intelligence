# DataCo Power BI Desktop report

Open **DataCo.pbix** in Power BI Desktop. It contains the loaded dataset and all seven report pages. Click **Home → Refresh** when you want to reload the CSV from:

`E:\Analysis project supply chain\raw data\DataCoSupplyChainDataset.csv`

The model reads the original CSV using Windows-1252 encoding and US date parsing. It removes personal names, street addresses, coordinates and duplicate financial columns, then adds date and elapsed-delay fields. No arrival timestamp is invented. The separate **DataCo.pbip** is an editable source project; keep its adjacent **DataCo.Report** and **DataCo.SemanticModel** folders together and refresh after opening that source project.

The report includes seven pages, native interactive charts and matrices, page slicers, and 37 explicit DAX measures. All financial totals include every order status unless a filter is applied; amounts are shown in source units. The shipping denominator excludes canceled shipments and counts each order once.

**Business Insights.md** explains the findings and recommended actions. **Measures.dax** and **Power Query.m** contain the measure and import definitions for inspection or reuse. The project uses Microsoft's documented PBIP/PBIR formats: https://learn.microsoft.com/en-us/power-bi/developer/projects/projects-report

If the source location changes, update File.Contents in Transform data → Fact → Advanced Editor, then refresh. Chart selections cross-filter or highlight related visuals. Use the horizontal scrollbar on monthly charts to reach the latest periods; use the matrix drill controls to explore country and city. Cloud publishing, sharing and scheduled refresh have not been configured.
