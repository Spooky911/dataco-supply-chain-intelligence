# Verification record

The CSV was analyzed in full with pandas. Item IDs are unique, all order-level shipping and destination fields checked are consistent within an order, and independently grouped order totals reconcile to the item totals. Expected headline values are recorded in **Metric Reconciliation.json**.

All 116 PBIR definition files pass the referenced Microsoft JSON schemas. The project opens in Power BI Desktop and the original CSV refresh succeeds. The initial overview displays 33.05M net booked sales, 3.97M recorded profit, 12.0% margin and a 57.3% late-delivery rate, matching the independent calculation.

All seven final pages were visually inspected in Desktop after refresh, including both portfolio scatterplots, the treemap, shipping comparison, destination matrix, order table and written insights. Selecting the Consumer bar reduced the customer and unit KPIs and updated the portfolio and matrix; clearing the selection restored full totals. Monthly charts include chronological sorting and horizontal scrolling. Cards abbreviate large counts; tables provide exact totals.

The first project-format save stalled after a model-format prompt. A fresh final copy was then successfully saved through Desktop as **DataCo.pbix**. The PBIX contains a loaded DataModel and seven PBIR pages; its ZIP integrity check passes. It was closed and reopened from disk: the executive page and its loaded KPI values were restored without a refresh. The separate source project remains available for editing.

The project is local and has not been published, shared or configured for scheduled refresh. Business Insights.md is a fixed full-dataset brief; it does not respond to slicers.
